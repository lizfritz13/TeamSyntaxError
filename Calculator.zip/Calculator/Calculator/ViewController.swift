//
//  ViewController.swift
//  Calculator
//
//  Created by Elizabeth Fritz on 4/26/16.
//  Copyright © 2016 Lizzle. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var calculatorDisplay: UILabel!
   
    var operandStack = [Double]()
    var operatorSymbol: String?
    var isTyping = false
    var numbersStack = [Double]()
    
    var displayValue: Double {
        
        set{
            self.calculatorDisplay.text = "\(newValue)"
        }
        
        get{
            return Double(self.calculatorDisplay.text!)!
        }
    }
    
    
    @IBAction func equalsPressed() {
        
        
    }
    
    
    @IBAction func numberPressed(sender: AnyObject!) {
        
        if isTyping {
            self.calculatorDisplay.text = self.calculatorDisplay.text! + sender.currentTitle!!
        } else {
            self.calculatorDisplay.text = sender.currentTitle!
            isTyping = true
        }

    
    func calculationPressed(sender: UIButton) {
        
        let operation = sender.currentTitle!
        
        switch operation {
            
        case "×":
            performOperation( { $0 * $1 } )
        case "+":
            performOperation( { $0 + $1 } )
        case "−":
            performOperation( { $1 - $0 } )
        case "÷":
            performOperation( { $1 / $0 } )
            
        default:
         break
        }
        

        print("\(operandStack) " + operatorSymbol!)
        }
    }
    
    func performOperation( operation: (Double, Double) -> Double)  {
        displayValue = operation(operandStack.removeLast(), operandStack.removeLast())
        operandStack.append(displayValue)
    }
    
    // User clears memory
    @IBAction func clear() {
        operandStack.removeAll()
        isTyping = false
        operatorSymbol = nil
        displayValue = 0
    }
}






    
